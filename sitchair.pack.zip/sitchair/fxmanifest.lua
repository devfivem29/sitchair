fx_version 'cerulean'
game 'gta5'
lua54 'yes'
author 'VotreNom'
description 'Script pour s\'asseoir sur des chaises et s\'allonger sur des lits'
version '1.0.0'

client_scripts {
    'config.lua',
    'locales.lua',
    'client.lua'
}

server_scripts {
    'server.lua'
}

dependency '/assetpacks'