Config = {}

Config.Locale = 'en'  -- 'en' for English, 'fr' for French

Config.SitProps = {
    'prop_chair_01a',
    'prop_chair_01b',
    'prop_chair_02',
    'prop_chair_03',
    'prop_chair_04a',
    'prop_chair_04b',
    'prop_chair_05',
    'prop_chair_pile_01',
    'prop_off_chair_01',
    'prop_off_chair_03',
    'prop_off_chair_04',
    'prop_off_chair_04b',
    'prop_off_chair_04_s',
    'prop_waiting_seat_01',
    'v_club_officechair',
    'v_club_stagechair',
    'v_res_d_armchair',
    'v_res_fh_easychair',
    'v_res_fh_singleseat',
    'v_res_j_armchair',
    'v_res_m_armchair',
    'v_res_mp_stripchair',
    'prop_bench_01a',
    'v_res_tre_chair'
}

Config.LayProps = {
    'v_med_bed1'
}

Config.SitKey = 38 -- E
Config.StandKey = 23 -- F
